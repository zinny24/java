package com.example.ex11.board;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.ex11.vo.BoardVO;



@Repository
public class BoardDaoImpl implements BoardDao {
	
	@Autowired
	SqlSession sqlSession;

	@Override
	public List<BoardVO> getBoardListAll(int start, int end, String searchOpt, String words) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("start", start);
		map.put("end", end);
		map.put("searchOpt", searchOpt);
		map.put("words", words);
		return sqlSession.selectList("board.getBoardListAll", map);
	}

	@Override
	public String setBoardInsertOne(BoardVO bvo) {
		try {
			sqlSession.insert("board.setBoardInsertOne", bvo);
			return "success";
			
		}catch(Exception e) {
			return "failed";
		}
				
	}

	@Override
	public BoardVO getBoardListOne(int bno) {
		return sqlSession.selectOne("board.getBoardListOne", bno);
	}

	@Override
	public void setViewCntUpdate(int bno) {
		sqlSession.update("board.setViewCntUpdate", bno);		
	}

	@Override
	public void setBoardUpdateOne(BoardVO bvo) {
		sqlSession.update("board.setBoardUpdateOne", bvo);		
	}

	@Override
	public void setBoardDeleteOne(int bno) {
		sqlSession.delete("board.setBoardDeleteOne", bno);		
	}

	@Override
	public int getBoardCount(String searchOpt, String words) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("searchOpt", searchOpt);
		map.put("words", words);
		return sqlSession.selectOne("board.getBoardCount", map);
	}
}
