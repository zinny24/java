package com.example.ex11.board;

import java.util.List;

import com.example.ex11.vo.BoardVO;

public interface BoardDao {
	
	public List<BoardVO> getBoardListAll(int start, int end, String searchOpt, String words);
	
	public int getBoardCount(String searchOpt, String words);
		
	public String setBoardInsertOne(BoardVO bvo);
	
	public BoardVO getBoardListOne(int bno);
	
	public void setViewCntUpdate(int bno);
	
	public void setBoardUpdateOne(BoardVO bvo);
	
	public void setBoardDeleteOne(int bno);
	
}
