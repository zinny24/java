package com.example.ex11.board;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.ex11.vo.BoardVO;

@Controller
public class BoardCtr {

	@Autowired
	BoardSrv boardSrv;

	@RequestMapping("/board/list")
	public ModelAndView getBoardList(@RequestParam(defaultValue = "title") String searchOpt,
			@RequestParam(defaultValue = "") String words, @RequestParam(defaultValue = "1") int curPage) {

		int count = boardSrv.getBoardCount(searchOpt, words);
		
		BoardPager boardPager = new BoardPager(count, curPage);
		int start = boardPager.getPageBegin();
		int end = boardPager.getPageEnd();
		
		List<BoardVO> list = boardSrv.getBoardListAll(start, end, searchOpt, words);
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("list", list);
		mav.addObject("count", count);
		mav.addObject("searchOpt", searchOpt);
		mav.addObject("words", words);
		mav.addObject("start", start);
		mav.addObject("end", end);
		mav.addObject("blockBegin", boardPager.getBlockBegin());
		mav.addObject("blockEnd", boardPager.getBlockEnd());
		mav.addObject("curBlock", boardPager.getCurBlock());
		mav.addObject("totalBlock", boardPager.getTotBlock());
		mav.addObject("prevPage", boardPager.getPrevPage());
		mav.addObject("nextPage", boardPager.getNextPage());
		mav.addObject("totalPage", boardPager.getTotPage());
		mav.addObject("curPage", boardPager.getCurPage());
		mav.addObject("selected", boardPager.getCurPage());
		
		
		mav.setViewName("board/boardList");
		return mav;
	}

	@RequestMapping("/board/write")
	public String getBoardForm() {
		return "board/boardForm";
	}

	@RequestMapping("/board/insert")
	@ResponseBody
	public String setBoardInsertOne(@ModelAttribute BoardVO bvo, HttpSession session) {
		String username = (String) session.getAttribute("username");
		
		bvo.setWriter(username);
		System.out.println(bvo.getWriter());
		System.out.println(boardSrv.setBoardInsertOne(bvo));
		
		return boardSrv.setBoardInsertOne(bvo);
	}

	@RequestMapping("/board/view")
	public ModelAndView getBoardListOne(@RequestParam int bno, HttpSession session) {
		boardSrv.setViewCntUpdate(bno, session);
		ModelAndView mav = new ModelAndView();
		mav.addObject("dto", boardSrv.getBoardListOne(bno));
		mav.setViewName("board/boardView");

		return mav;
	}

	@RequestMapping("/board/delete")
	public String setBoardDeleteOne(@RequestParam int bno) {
		boardSrv.setBoardDeleteOne(bno);
		return "redirect:/board/list";
	}

	@RequestMapping("/board/update")
	public String setBoardUpdateOne(@ModelAttribute BoardVO bvo) {
		boardSrv.setBoardUpdateOne(bvo);
		return "redirect:/board/list";
	}
}
