package com.example.ex11.board;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ex11.vo.BoardVO;

@Service
public class BoardSrvImpl implements BoardSrv {

	@Autowired
	BoardDao boardDao;

	@Override
	public List<BoardVO> getBoardListAll(int start, int end, String searchOpt, String words) {
		return boardDao.getBoardListAll(start, end, searchOpt, words);
	}

	@Override
	public String setBoardInsertOne(BoardVO bvo) {
			bvo.setContent(bvo.getContent().replace("<", "&lt;"));
			bvo.setContent(bvo.getContent().replace(">", "&gt;"));
			bvo.setContent(bvo.getContent().replace(" ", "&nbsp;"));
			bvo.setContent(bvo.getContent().replace("\n", "<br>"));
			String result = boardDao.setBoardInsertOne(bvo);
		return result;
	}

	@Override
	public BoardVO getBoardListOne(int bno) {
		return boardDao.getBoardListOne(bno);
	}

	@Override
	public void setViewCntUpdate(int bno, HttpSession session) {
		// ���� Ÿ�� ��������
		long getSessionTime = 0;
		if (session.getAttribute("getSessionTime_" + bno) != null)
			getSessionTime = (Long) session.getAttribute("getSessionTime_" + bno);

		long getCurrentTime = System.currentTimeMillis();
		if ((getCurrentTime - getSessionTime) > 5 * 1000) {
			boardDao.setViewCntUpdate(bno);
			session.setAttribute("getSessionTime_" + bno, getCurrentTime);
		}

		System.out.println(getSessionTime);
		System.out.println(getCurrentTime);
	}

	@Override
	public void setBoardUpdateOne(BoardVO bvo) {
		boardDao.setBoardUpdateOne(bvo);
	}

	@Override
	public void setBoardDeleteOne(int bno) {
		boardDao.setBoardDeleteOne(bno);
	}
	
	@Override
	public int getBoardCount(String searchOpt, String words) {
		return boardDao.getBoardCount(searchOpt, words);
	}

}
