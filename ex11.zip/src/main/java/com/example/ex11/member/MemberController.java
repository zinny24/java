package com.example.ex11.member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.ex11.vo.Member;

@Controller
@RequestMapping(value = "/member")
public class MemberController {
		
	@Autowired
	MemberService memberService;
	
	@RequestMapping(value = "/")
	public String getMemberMain() {
		return "index";
	}
	
	@RequestMapping(value = "/list")
	public String getMemberList(Model model) {
		model.addAttribute("list", memberService.getMemberList());
		return "member/getMemberList";
	}
	
	@RequestMapping(value = "/write")
	public String getMemberWrite() {
		return "member/getMemberWrite";
	}
	
	@RequestMapping(value = "/insert")
	public String setMemberWrite(@ModelAttribute Member member) {
		memberService.insertMember(member);
		return "redirect:/member/list";
	}
	
	@RequestMapping(value = "/view", method = RequestMethod.GET)
	public String memberView(@RequestParam int mid, Model model){
		model.addAttribute("dto", memberService.getMemberOne(mid));
		return "member/getMemberView";
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public String memberUpdate(@ModelAttribute Member member){
		memberService.updateMember(member);
		return "redirect:/member/list";
	}
	
	@RequestMapping("/delete")
	public String memberDelete(@RequestParam int mid, @RequestParam String userid, @RequestParam String passwd, Model model){
		boolean result = memberService.checkPasswd(userid, passwd);
		if(result){
			memberService.deleteMember(mid);
			return "redirect:/member/list";
			
		} else {
			model.addAttribute("message", "��й�ȣ�� Ȯ���ϼ���");
			model.addAttribute("dto", memberService.getMemberOne(mid));
			return "member/getMemberView";
		}
	}
	
}
