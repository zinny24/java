package com.example.ex11.member;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.ex11.vo.Member;

@Repository
public class MemberDaoImpl implements MemberDao {

	@Autowired
	SqlSession sqlSession;

	@Override
	public List<Member> getMemberList() {
		return sqlSession.selectList("member.getMemberList");
	}

	@Override
	public Member getMemberOne(int mid) {
		return sqlSession.selectOne("member.getMemberOne", mid);
	}

	@Override
	public void insertMember(Member member) {
		sqlSession.insert("member.insertMember", member);
	}

	@Override
	public void deleteMember(int mid) {
		sqlSession.delete("member.deleteMember", mid);
	}

	@Override
	public void updateMember(Member member) {
		sqlSession.update("member.updateMember", member);
	}

	@Override
	public int countMember() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean checkPasswd(String userid, String passwd) {
		boolean result = false;
		Map<String, String> map = new HashMap<String, String>();
		map.put("userid", userid);
		map.put("passwd", passwd);

		int count = sqlSession.selectOne("member.checkPasswd", map);
		if (count == 1)
			result = true;

		return result;
	}

}
