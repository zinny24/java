package com.example.ex11.member;


import java.util.List;

import com.example.ex11.vo.Member;

public interface MemberService {
	
	public List<Member> getMemberList();

	public Member getMemberOne(int mid);

	public void insertMember(Member member);

	public void deleteMember(int mid);

	public void updateMember(Member member);
	
	public boolean checkPasswd(String userid, String passwd);

	public int countMember();
}
