package com.example.ex11.member;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ex11.vo.Member;

@Service
public class MemberServiceImpl implements MemberService {
	
	@Autowired
	MemberDao memberDao;

	@Override
	public List<Member> getMemberList() {
		return memberDao.getMemberList();
	}

	@Override
	public Member getMemberOne(int mid) {
		return memberDao.getMemberOne(mid);
	}

	@Override
	public void insertMember(Member member) {
		memberDao.insertMember(member);
	}

	@Override
	public void deleteMember(int mid) {
		memberDao.deleteMember(mid);
	}

	@Override
	public void updateMember(Member member) {
		memberDao.updateMember(member);		
	}

	@Override
	public int countMember() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean checkPasswd(String userid, String passwd) {
		return memberDao.checkPasswd(userid, passwd);
	}

}
