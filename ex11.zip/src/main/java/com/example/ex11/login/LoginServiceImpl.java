package com.example.ex11.login;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ex11.vo.Member;

@Service
public class LoginServiceImpl implements LoginService {
	
	@Autowired
	LoginDao loginDao;

	@Override
	public int loginCheck(Member member, HttpSession session) {
		if( loginDao.loginCheck(member, session) > 0 ) {
			Member mem = loginDao.getMember(member);
			session.setAttribute("userid", mem.getUserid());
			session.setAttribute("username", mem.getName());
		}
		return loginDao.loginCheck(member, session);
	}
	
	@Override
	public Member getMember(Member member) {
		return loginDao.getMember(member);
	}

	@Override
	public void logout(HttpSession session) {
		session.invalidate();
	}

}
