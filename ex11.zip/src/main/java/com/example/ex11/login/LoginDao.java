package com.example.ex11.login;

import javax.servlet.http.HttpSession;

import com.example.ex11.vo.Member;

public interface LoginDao {

	public int loginCheck(Member member, HttpSession session);
	
	public Member getMember(Member member);

	public void logout(HttpSession session);

}
