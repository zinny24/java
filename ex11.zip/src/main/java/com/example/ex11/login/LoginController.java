package com.example.ex11.login;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.ex11.vo.Member;

@Controller
public class LoginController {
	
	@Autowired
	LoginService loginService;

	@RequestMapping("/login")
	public String getLoginPage() {
		return "login/login";
	}
	
	@RequestMapping("/loginCheck")
	public ModelAndView loginCheck(@ModelAttribute Member member, HttpSession session) {
		int result = loginService.loginCheck(member, session);
		ModelAndView mav = new ModelAndView();
		if( result > 0 ) {
			mav.addObject("msg", "success");
			mav.setViewName("main");
		
		}else {
			mav.addObject("msg", "failure");
			mav.setViewName("login/login");
		}
		return mav;	
	}
	
	@RequestMapping("/logout")
	public ModelAndView setLogout(HttpSession session) {
		loginService.logout(session);
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("msg", "logout");
		mav.setViewName("login/login");
		
		return mav;
	}
}











