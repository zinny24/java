package com.example.ex11.login;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.ex11.vo.Member;

@Repository
public class LoginDaoImpl implements LoginDao {
	
	@Autowired
	SqlSession sqlSession;

	@Override
	public int loginCheck(Member member, HttpSession session) {
		return sqlSession.selectOne("login.loginCheck", member);
	}
	
	@Override
	public Member getMember(Member member) {
		return sqlSession.selectOne("login.getMember", member);
	}

	@Override
	public void logout(HttpSession session) {
		
	}

}
