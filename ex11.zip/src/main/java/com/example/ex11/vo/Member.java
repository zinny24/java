package com.example.ex11.vo;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Member {
	private int mid;
	private String userid;
	private String passwd;
	private String name;
	private String email;
	private Date regdate;
	private Date regupdate;
	
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	
	public int getMid() {
		return mid;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getRegdate() {
		return sdf.format(regdate);
	}
	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}
	public String getRegupdate() {
		return sdf.format(regupdate);
	}
	public void setRegupdate(Date regupdate) {
		this.regupdate = regupdate;
	}
}
