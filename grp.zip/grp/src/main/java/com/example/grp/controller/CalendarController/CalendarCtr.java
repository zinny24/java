package com.example.grp.controller.CalendarController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/calendar")
public class CalendarCtr {

	@RequestMapping("")
	public String getCalendarHome() {
		return "grp_calendar/grp_calendar_main";
	}
	
}
