package com.example.grp.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.grp.model.BuseoVO;
import com.example.grp.model.GradeVO;
import com.example.grp.model.RegisterVO;
import com.example.grp.repository.RegisterDao;

@Service
public class RegisterServiceImpl implements RegisterService {

	@Autowired
	RegisterDao registerDao;

	@Override
	public List<BuseoVO> getBuseoList() {
		return registerDao.getBuseoList();
	}

	@Override
	public List<GradeVO> getGradeList() {
		return registerDao.getGradeList();
	}

	@Override
	public int getEmpNumCheck(String empNum) {
		return registerDao.getEmpNumCheck(empNum);
	}

	@Override
	public void setRegister(RegisterVO rvo) {
		registerDao.setRegisterOne(rvo);
	}

	@Override
	public void setRegisterOthersOne(RegisterVO rvo) {
		registerDao.setRegisterOthersOne(rvo);
	}

	@Override
	public void setEmployeeAuthChange(String auth, String empNum) {
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("auth", auth);
		map.put("empNum", empNum);
		registerDao.setEmployeeAuthChange(map);
	}

	@Override
	public void setEmployeeHeadChange(String headType, String empNum) {
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("headType", headType);
		map.put("empNum", empNum);
		registerDao.setEmployeeHeadChange(map);
	}
}
