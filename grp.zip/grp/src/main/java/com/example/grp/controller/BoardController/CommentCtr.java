package com.example.grp.controller.BoardController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.grp.model.CommentVO;
import com.example.grp.service.commentSrv.CommentSrv;

@Controller
@RequestMapping("/comment")
public class CommentCtr {
	
	@Autowired
	CommentSrv cSrv;

	@RequestMapping("/grp_comment_list")
	@ResponseBody
	private Map<String, Object> getCommentList(@ModelAttribute CommentVO cvo) throws Exception {
		int cCount	= cSrv.getCommentCount(cvo);
		List<CommentVO> list = cSrv.getCommentList(cvo);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("list", list);
		map.put("cCount", cCount);
		return map;
	}

	@RequestMapping("/grp_comment_register")
	@ResponseBody
	private int setComment(@ModelAttribute CommentVO cvo) throws Exception {
		return cSrv.setComment(cvo);
	}

	@RequestMapping("/grp_comment_modify")
	@ResponseBody
	private int setCommentModify(@ModelAttribute CommentVO cvo) throws Exception {
		return cSrv.setCommentModify(cvo);
	}

	@RequestMapping("/grp_comment_delete") // 댓글 삭제
	@ResponseBody
	private int setCommentDelete(@ModelAttribute CommentVO cvo) throws Exception {
		return cSrv.setCommentDelete(cvo);
	}
}
