package com.example.grp.repository.commentDao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.grp.model.CommentVO;

@Repository
public class CommentDao {
	
	@Autowired
	private SqlSession sql;
	
	
	public List<CommentVO> getCommentList(CommentVO cvo) {
		return sql.selectList("comment.getCommentList", cvo);
	}

	
	public int setComment(CommentVO cvo) {
		return sql.insert("comment.setComment", cvo);
	}

	
	public int setCommentModify(CommentVO cvo) {
		return sql.update("comment.setCommentModify", cvo);
	}

	
	public int setCommentDelete(CommentVO cvo) {
		return sql.delete("comment.setCommentDelete", cvo);
	}

	
	public int getCommentCount(CommentVO cvo) {
		return sql.selectOne("comment.getCommentCount", cvo);
	}
}
