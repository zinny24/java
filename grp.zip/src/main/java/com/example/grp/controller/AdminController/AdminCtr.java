package com.example.grp.controller.AdminController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/grp_admin")
public class AdminCtr {

	@RequestMapping("")
	public String getAdminHome() {
		return "grp_admin/grp_admin_main";
	}
}
