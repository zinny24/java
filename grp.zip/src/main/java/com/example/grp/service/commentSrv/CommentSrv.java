package com.example.grp.service.commentSrv;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.grp.model.CommentVO;
import com.example.grp.repository.commentDao.CommentDao;

@Service
public class CommentSrv {
	@Autowired
	CommentDao cdao;

	
	public List<CommentVO> getCommentList(CommentVO cvo) {
		return cdao.getCommentList(cvo);
	}

	
	public int setComment(CommentVO cvo) {
		return cdao.setComment(cvo);
	}

	
	public int setCommentModify(CommentVO cvo) {
		return cdao.setCommentModify(cvo);
	}

	
	public int setCommentDelete(CommentVO cvo) {
		return cdao.setCommentDelete(cvo);
	}

	
	public int getCommentCount(CommentVO cvo) {
		return cdao.getCommentCount(cvo);
	}
}
