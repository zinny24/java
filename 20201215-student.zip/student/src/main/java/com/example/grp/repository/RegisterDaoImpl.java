package com.example.grp.repository;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.grp.model.BuseoVO;
import com.example.grp.model.GradeVO;
import com.example.grp.model.RegisterVO;

@Repository
public class RegisterDaoImpl implements RegisterDao {

	@Autowired
	SqlSession sql;
	
	
	@Override
	public List<BuseoVO> getBuseoList() {
		return sql.selectList("buseo.getBuseoList");
	}


	@Override
	public List<GradeVO> getGradeList() {
		return sql.selectList("grade.getGradeList");
	}


	@Override
	public int getEmpNumCheck(String empNum) {
		return sql.selectOne("register.getEmpNumCheck", empNum);
	}


	@Override
	public void setRegisterOne(RegisterVO rvo) {
		sql.insert("register.setRegisterOne", rvo);
	}


	@Override
	public void setRegisterOthersOne(RegisterVO rvo) {
		sql.insert("register.setRegisterOthersOne", rvo);
	}

	@Override
	public void setEmployeeAuthChange(HashMap<String, String> map) {
		sql.update("register.setEmployeeAuthChange", map);
	}


	@Override
	public void setEmployeeHeadChange(HashMap<String, String> map) {
		sql.update("register.setEmployeeHeadChange", map);
	}

}
