package com.example.grp.controller.ReferenceController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/reference")
public class ReferenceCtr {

	@RequestMapping("")
	public String getReferenceHome() {
		return "grp_reference/grp_reference_main";
	}
	
}