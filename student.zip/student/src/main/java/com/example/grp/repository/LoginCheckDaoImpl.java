package com.example.grp.repository;

import javax.servlet.http.HttpSession;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.grp.model.RegisterVO;

@Repository
public class LoginCheckDaoImpl implements LoginCheckDao {
	
	@Autowired
	SqlSession sql;

	@Override
	public RegisterVO loginCheck(RegisterVO rvo) {
		System.out.println("Repository");
		System.out.println("mappers");
		return sql.selectOne("login.loginCheck", rvo);
	}

	@Override
	public void logout(HttpSession httpSession) {}

}
