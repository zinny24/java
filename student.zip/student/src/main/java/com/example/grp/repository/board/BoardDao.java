package com.example.grp.repository.board;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.grp.model.BoardVO;

@Repository
public class BoardDao {

	@Autowired
	SqlSession sqlSession;
	
	public void setBoard(BoardVO bvo) {
		sqlSession.insert("board.setBoard", bvo);
	}
	
	public List<BoardVO> getBoardList(int start, int end, String words, String searchOpt) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("start", start);
		map.put("end", end);
		map.put("words", words);
		map.put("searchOpt", searchOpt);
		return sqlSession.selectList("board.getBoardList", map);
	}

	public int getBoardCount(String words, String searchOpt) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("words", words);
		map.put("searchOpt", searchOpt);
		return sqlSession.selectOne("board.getBoardCount", map);
	}
	
	public void createArticleTbl(String boardCode) {
		String str = "CREATE TABLE gat_article_" + boardCode;
		str += "(aid int not null auto_increment primary key,";
		str += "division char(1),";
		str += "subject varchar(300) not null,";
		str += "writer varchar(20) not null,";
		str += "content text,";
		str += "regdate datetime,";
		str += "hit int default 0,";
		str += "fileName varchar(300),";
		str += "fileOriName varchar(300),";
		str += "fileUrl varchar(500),";
		str += "ref int,";
		str += "re_step int,";
		str += "re_level int);";
		Map<String, String> map = new HashMap<String, String>();
		map.put("str", str);
		sqlSession.update("board.createArticleTbl", map);

	}
	
	public void createCommentTbl(String boardCode) {
		String str = "CREATE TABLE gat_comment_" + boardCode;
		str += "(cid int not null auto_increment primary key,";
		str += "aid int not null,";
		str += "comment text,";
		str += "who varchar(20),";
		str += "regdate datetime);";
		Map<String, String> map = new HashMap<String, String>();
		map.put("str", str);
		sqlSession.update("board.createCommentTbl", map);
	}
	
	public int getBoardCheck(String boardCode) {
		return sqlSession.selectOne("board.getBoardExist", boardCode);
	}

	public void setBoardDelete(String boardCode) {
		sqlSession.delete("board.setBoardDelete", boardCode);
	}

	public void dropArticleTbl(String boardCode) {
		String str = "drop TABLE gat_article_" + boardCode;
		Map<String, String> map = new HashMap<String, String>();
		map.put("str", str);
		sqlSession.insert("board.dropArticleTbl", map);
	}

	public void dropCommentTbl(String boardCode) {
		String str = "drop TABLE gat_comment_" + boardCode;
		Map<String, String> map = new HashMap<String, String>();
		map.put("str", str);
		sqlSession.insert("board.dropCommentTbl", map);
	}

	public int getBoardCountAll() {
		return sqlSession.selectOne("board.getBoardCountAll");
	}

	public void setBoardDeleteAll(String boardCode) {
		sqlSession.delete("board.setBoardDeleteAll", boardCode);
	}
	
}
