package com.example.grp.model;

public class ComVO {
	private String comName;
	private String comSubName;
	private String comCeo;
	private String comTel;
	private String comUrl;
	private String comCopy;
	private int comAuth;
	
	public String getComName() {
		return comName;
	}
	public void setComName(String comName) {
		this.comName = comName;
	}
	public String getComSubName() {
		return comSubName;
	}
	public void setComSubName(String comSubName) {
		this.comSubName = comSubName;
	}
	public String getComCeo() {
		return comCeo;
	}
	public void setComCeo(String comCeo) {
		this.comCeo = comCeo;
	}
	public String getComTel() {
		return comTel;
	}
	public void setComTel(String comTel) {
		this.comTel = comTel;
	}
	public String getComUrl() {
		return comUrl;
	}
	public void setComUrl(String comUrl) {
		this.comUrl = comUrl;
	}
	public String getComCopy() {
		return comCopy;
	}
	public void setComCopy(String comCopy) {
		this.comCopy = comCopy;
	}
	public int getComAuth() {
		return comAuth;
	}
	public void setComAuth(int comAuth) {
		this.comAuth = comAuth;
	}
}
