package com.example.grp.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.grp.model.RegisterVO;
import com.example.grp.repository.EmployeeDao;

@Service
public class EmployeeSrvImpl implements EmployeeSrv {
	
	@Autowired
	EmployeeDao employeeDao;

	@Override
	public void setEmployeeDeleteOne(String empNum) {
		employeeDao.setEmployeeDeleteOne(empNum);
	}

	@Override
	public int setEmployeeDeleteAll(int empID) {
		return employeeDao.setEmployeeDeleteAll(empID);
	}
	
	@Override
	public List<RegisterVO> getEmployeeListAll(int start, int end, String words, String searchOpt) {
		return employeeDao.getEmployeeListAll(start, end, words, searchOpt);
	}

	@Override
	public int getEmployeeCount(String searchOpt, String words) {
		// TODO Auto-generated method stub
		return employeeDao.getEmployeeCount(searchOpt, words);
	}

	@Override
	public RegisterVO getEmployeeNeedOne(RegisterVO rvo) {
		return employeeDao.getEmployeeNeedOne(rvo);
	}

}