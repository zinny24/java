package com.example.grp.service.commentSrv;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.grp.model.CommentVO;
import com.example.grp.repository.commentDao.CommentDao;

@Service
public class CommentSrv {

	@Autowired
	CommentDao cDao;
	
	public void setComment(CommentVO cvo) {
		cDao.setComment(cvo);
	}
	
	//�Խ��� �ڵ�(boardCode), �Խù� ��ȣ(aid)
	public List<CommentVO> getCommentList(CommentVO cvo) {
		return cDao.getCommentList(cvo);
	}
	
	public int getCommentCount(CommentVO cvo) {
		return cDao.getCommentCount(cvo);
	}
	
	public void setCommentDelete(CommentVO cvo) {
		cDao.setCommentDelete(cvo);
	}
	
	public void setCommentModify(CommentVO cvo) {
		cDao.setCommentModify(cvo);
	}
	
}









