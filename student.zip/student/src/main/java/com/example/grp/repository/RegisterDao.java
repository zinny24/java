package com.example.grp.repository;

import java.util.HashMap;
import java.util.List;

import com.example.grp.model.BuseoVO;
import com.example.grp.model.GradeVO;
import com.example.grp.model.RegisterVO;

public interface RegisterDao {
	public List<BuseoVO> getBuseoList();
	
	public List<GradeVO> getGradeList();
	
	public int getEmpNumCheck(String empNum);
	
	public void setRegisterOne(RegisterVO rvo);
	
	public void setRegisterOthersOne(RegisterVO rvo);
	
	public void setEmployeeAuthChange(HashMap<String, String> map);
	
	public void setEmployeeHeadChange(HashMap<String, String> map);
}
