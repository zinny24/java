package com.example.grp.repository.cal;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.grp.model.CalVO;

@Repository
public class CalDao {
	
	@Autowired
	SqlSession sql;
	
	public void setCal(CalVO cvo) {
		sql.insert("calendar.setCal", cvo);
	}
	
	public List<CalVO> getCal() {
		return sql.selectList("calendar.getCal");
	}
}












