package com.example.grp.controller.CalendarController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.grp.model.CalVO;
import com.example.grp.service.cal.CalSrv;

@Controller
@RequestMapping("/calendar")
public class CalendarCtr {
	
	@Autowired
	CalSrv cSrv;

	@RequestMapping("")
	public String getCalendarHome() {
		return "grp_calendar/grp_calendar_main";
	}
	
	@RequestMapping("/grp_calendar_add")
	@ResponseBody
	public void setCal(@ModelAttribute CalVO cvo) {
		cSrv.setCal(cvo);
	}
	
	@RequestMapping("/grp_calendar_list")
	@ResponseBody
	public List<CalVO> getCal() {
		List<CalVO> list = cSrv.getCal();
		
		return list;
	}
	
}














