package com.example.grp.service;

import javax.servlet.http.HttpSession;

import com.example.grp.model.RegisterVO;

public interface LoginCheckSrv {
	public RegisterVO loginCheck(RegisterVO rvo, HttpSession session);
	
	public void logout(HttpSession httpSession);
}
