package com.example.grp.repository;

import javax.servlet.http.HttpSession;

import com.example.grp.model.RegisterVO;

public interface LoginCheckDao {
	
	public RegisterVO loginCheck(RegisterVO rvo);
	
	public void logout(HttpSession httpSession);
	
}
