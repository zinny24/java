package com.example.grp.service.company;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.grp.model.ComVO;
import com.example.grp.repository.company.ComDao;

@Service
public class ComSrv {
	
	@Autowired
	ComDao mDao;
	
	public ComVO getCompany() {
		return mDao.getCompany();
	}
	
	public void setCompany(ComVO cvo) {
		mDao.setCompany(cvo);
	}
}
