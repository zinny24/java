package com.example.grp.controller;

import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.grp.model.BuseoVO;
import com.example.grp.model.GradeVO;
import com.example.grp.model.RegisterVO;
import com.example.grp.service.EmployeeSrv;
import com.example.grp.service.LoginCheckSrv;
import com.example.grp.service.RegisterService;
import com.example.grp.service.company.ComSrv;

@Controller
public class IDnRegController {
	
	@Autowired
	RegisterService registerSrv;
	
	@Autowired
	LoginCheckSrv loginCheckSrv;
	
	@Autowired
	EmployeeSrv empSrv;
	
	@Autowired
	ComSrv cSrv;

	@RequestMapping(value = "/grp_login", method = RequestMethod.GET)
	public ModelAndView getLogin() {
		String companyName = cSrv.getCompany().getComName();
		String companySubName = cSrv.getCompany().getComSubName();
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("companyName", companyName);
		mav.addObject("companySubName", companySubName);
		mav.setViewName("grp_login");
		
		return mav;
	}
	
	@RequestMapping(value = "/grp_login", method = RequestMethod.POST)
	public ModelAndView setLogin(@ModelAttribute RegisterVO rvo, HttpSession httpSession) {
		//System.out.println(empSrv.getEmployeeNeedOne(rvo));
		
		ModelAndView mav = new ModelAndView();
		
		String cfm = empSrv.getEmployeeNeedOne(rvo).getEmpConfirm();
		int auth = empSrv.getEmployeeNeedOne(rvo).getEmpAuth();
		int comAuth = cSrv.getCompany().getComAuth();
		
		if( empSrv.getEmployeeNeedOne(rvo) != null ) {
			if( cfm.equals("Y") && auth > comAuth) {
				loginCheckSrv.loginCheck(rvo, httpSession);
				mav.setViewName("redirect:/grp_admin");
				
			}else if( cfm.equals("Y") && auth < comAuth) {
				loginCheckSrv.loginCheck(rvo, httpSession);
				mav.setViewName("redirect:/");
				
			}else {
				mav.addObject("msg", "관리자의 승인이 필요합니다.");
				mav.setViewName("/grp_login");
			}
		}else {		
			mav.addObject("msg", "아이디/비밀번호를 확인하세요.");
			mav.setViewName("/grp_login");
		}
		return mav;
	}
	
	@RequestMapping("/grp_logout")
	@ResponseBody
	public String grpLogout(HttpSession httpSession) {
		loginCheckSrv.logout(httpSession);
		return "success";
	}
	
	@RequestMapping(value = "/grp_register", method = RequestMethod.GET)
	public String getRegister() {
		return "grp_register";
	}
	
	@RequestMapping(value = "/grp_chk_empNum", method = RequestMethod.POST)
	@ResponseBody
	public String chkEmpNum(@RequestParam("empNum") String empNum) {
		
		String msg;
		int empNumCheck = registerSrv.getEmpNumCheck(empNum);
		
		if( empNumCheck > 0 ) {
			msg = "failure";
		}else {
			msg = "success";
		}
		
		return msg;
	}
	
	@RequestMapping(value = "/grp_register", method = RequestMethod.POST)
	public String setRegister(@ModelAttribute RegisterVO employeeVO) {
		Calendar cal = Calendar.getInstance();
		int enterYear  = Integer.parseInt(employeeVO.getEmpEnter().substring(0, 4));
		System.out.println(enterYear);
		
		int regYear	= cal.get(Calendar.YEAR);
		System.out.println(regYear);
		
		int stepSize = regYear - enterYear + 1;
		//System.out.println(stepSize);
		employeeVO.setEmpStep(stepSize);
		
		String num = enterYear + employeeVO.getEmpBuseoCode() + employeeVO.getEmpGradeCode();
		employeeVO.setEmpNum(num);
		
		registerSrv.setRegister(employeeVO);
		return "redirect:/grp_login";
	}
	
	@RequestMapping(value = "/grp_get_buseo", method = RequestMethod.POST)
	@ResponseBody
	public List<BuseoVO> getBuseo() {
		List<BuseoVO> list = registerSrv.getBuseoList();
		//System.out.println(list);
		return list;
	}
	
	@RequestMapping(value = "/grp_get_grade", method = RequestMethod.POST)
	@ResponseBody
	public List<GradeVO> getGrade() {
		List<GradeVO> list = registerSrv.getGradeList();
		//System.out.println(list);
		return list;
	}
	
}
