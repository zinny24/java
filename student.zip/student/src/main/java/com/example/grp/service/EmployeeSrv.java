package com.example.grp.service;

import java.util.List;

import com.example.grp.model.RegisterVO;

public interface EmployeeSrv {

	public void setEmployeeDeleteOne(String empNum);
	
	public int setEmployeeDeleteAll(int empID);
	
	public List<RegisterVO> getEmployeeListAll(int start, int end, String words, String searchOpt);
	
	public int getEmployeeCount(String searchOpt, String words);
	
	public RegisterVO getEmployeeNeedOne(RegisterVO rvo);
}
