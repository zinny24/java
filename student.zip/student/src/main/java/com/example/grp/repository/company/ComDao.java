package com.example.grp.repository.company;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.grp.model.ComVO;

@Repository
public class ComDao {
	
	@Autowired
	SqlSession sqlSession;
	
	/*public void majorCreateTbl(int major) {
		
		int exTbl = sqlSession.selectOne("company.majorCheck");
		
		String dropTbl = "DROP TABLE grp_major;";
		
		String createTbl = "CREATE TABLE grp_major(";
		createTbl += "mid int not null auto_increment,";
		for(int i = 0; i < major; i++) {
			createTbl += "majorUrl"+i+" varchar(500),";
			createTbl += "majorName"+i+" varchar(100),";
		}
		createTbl += "primary key(mid)";
		createTbl += ");";
		
		Map<String, String> cMap = new HashMap<String, String>();
		Map<String, String> dMap = new HashMap<String, String>();
		if( exTbl > 0 ) {
			dMap.put("dropTbl", dropTbl);
			cMap.put("createTbl", createTbl);
			sqlSession.insert("company.majorDropTbl", dMap);
			sqlSession.insert("company.majorCreateTbl", cMap);
		}else {
			cMap.put("createTbl", createTbl);
			sqlSession.insert("company.majorCreateTbl", cMap);
		}
	}*/
	
	public ComVO getCompany() {
		return sqlSession.selectOne("company.getCompany");
	}
	
	public void setCompany(ComVO cvo) {
		sqlSession.update("company.setCompany", cvo);
	}
}
