package com.example.grp.controller.CompanyController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.grp.model.ComVO;
import com.example.grp.service.company.ComSrv;

@Controller
@RequestMapping("/company")
public class CompanyCtr {
	
	@Autowired
	ComSrv comSrv;

	@RequestMapping(value = "", method = RequestMethod.GET)
	public String getGrpCompany() {
		return "grp_company/grp_company_main";
	}
	
	@RequestMapping(value = "", method = RequestMethod.POST)
	@ResponseBody
	public ComVO getCompany() {
		ComVO cvo = comSrv.getCompany();
		System.out.println(cvo);
		return cvo;
	}
	
	@RequestMapping(value = "/grp_company", method = RequestMethod.POST)
	public String setCompnay(@ModelAttribute ComVO cvo) {
		comSrv.setCompany(cvo);
		return "grp_company/grp_company_main";
	}
	
	/*@RequestMapping(value = "/grp_major", method = RequestMethod.POST)
	@ResponseBody
	public String majorCreateTbl(@RequestParam String major) {
		mSrv.majorCreateTbl(Integer.parseInt(major));
		return "aaa";
	}*/
}