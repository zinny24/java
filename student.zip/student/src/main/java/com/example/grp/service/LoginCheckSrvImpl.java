package com.example.grp.service;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.grp.model.RegisterVO;
import com.example.grp.repository.LoginCheckDao;

@Service
public class LoginCheckSrvImpl implements LoginCheckSrv {
	
	@Autowired
	LoginCheckDao loginCheckDao;

	@Override
	public RegisterVO loginCheck(RegisterVO rvo, HttpSession httpSession) {
		RegisterVO result = loginCheckDao.loginCheck(rvo);
		
		if( result != null ) {
			httpSession.setAttribute("empBuseoCode", result.getEmpBuseoCode());
			httpSession.setAttribute("empBuseoName", result.getEmpBuseoName());
			
			httpSession.setAttribute("empGradeCode", result.getEmpGradeCode());
			httpSession.setAttribute("empGradeName", result.getEmpGradeName());
			
			httpSession.setAttribute("empNum", result.getEmpNum());
			httpSession.setAttribute("empName", result.getEmpName());
			httpSession.setAttribute("empConfirm", result.getEmpConfirm());
			httpSession.setAttribute("empAuth", result.getEmpAuth());
		}
		
		return result;
	}

	@Override
	public void logout(HttpSession httpSession) {
		httpSession.invalidate();		
	}

}
