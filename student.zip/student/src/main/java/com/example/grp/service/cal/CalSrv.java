package com.example.grp.service.cal;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.grp.model.CalVO;
import com.example.grp.repository.cal.CalDao;

@Service
public class CalSrv {

	@Autowired
	CalDao cDao;
	
	public void setCal(CalVO cvo) {
		cDao.setCal(cvo);
	}
	
	public List<CalVO> getCal() {
		return cDao.getCal();
	}
}









