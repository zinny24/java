package com.example.grp.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.grp.model.RegisterVO;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {

	@Autowired
	SqlSession sqlSession;
	
	@Override
	public void setEmployeeDeleteOne(String empNum) {
		sqlSession.delete("employee.setEmployeeDeleteOne", empNum);		
	}

	@Override
	public int setEmployeeDeleteAll(int empID) {
		return sqlSession.delete("employee.setEmployeeDeleteAll", empID);
	}
	
	@Override
	public List<RegisterVO> getEmployeeListAll(int start, int end, String words, String searchOpt) {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("start", start);
		map.put("end", end);
		map.put("words", words);
		map.put("searchOpt", searchOpt);
		return sqlSession.selectList("employee.getEmployeeListAll", map);
	}

	@Override
	public int getEmployeeCount(String searchOpt, String words) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("searchOpt", searchOpt);
		map.put("words", words);
		return sqlSession.selectOne("employee.getEmployeeCount", map);
	}

	@Override
	public RegisterVO getEmployeeNeedOne(RegisterVO rvo) {
		return sqlSession.selectOne("employee.getEmployeeNeedOne", rvo);
	}

}
