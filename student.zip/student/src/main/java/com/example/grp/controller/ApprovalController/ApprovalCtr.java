package com.example.grp.controller.ApprovalController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/approval")
public class ApprovalCtr {

	@RequestMapping("")
	public String getApprovalHome() {
		return "grp_approval/grp_approval_main";
	}
	
	@RequestMapping(value = "/grp_approval_ready", method = RequestMethod.GET)
	public String getApprovalReady() {
		return "grp_approval/grp_approval_ready";
	}
	
	@RequestMapping(value = "/grp_approval_status", method = RequestMethod.GET)
	public String getApprovalStatus() {
		return "grp_approval/grp_approval_status";
	}
	
	@RequestMapping(value = "/grp_approval_ref", method = RequestMethod.GET)
	public String getApprovalRef() {
		return "grp_approval/grp_approval_ref";
	}
	
	@RequestMapping(value = "/grp_approval_send_save", method = RequestMethod.GET)
	public String getApprovalSend() {
		return "grp_approval/grp_approval_send_save";
	}
	
	@RequestMapping(value = "/grp_approval_receive_save", method = RequestMethod.GET)
	public String getApprovalReceive() {
		return "grp_approval/grp_approval_receive_save";
	}
	
	@RequestMapping(value = "/grp_approval_temp_save", method = RequestMethod.GET)
	public String getApprovalTemp() {
		return "grp_approval/grp_approval_temp_save";
	}
	
	@RequestMapping(value = "/grp_approval_ref_save", method = RequestMethod.GET)
	public String getApprovalRefSave() {
		return "grp_approval/grp_approval_ref_save";
	}
	
	@RequestMapping(value = "/grp_approval_form", method = RequestMethod.GET)
	public String getApprovalForm() {
		return "grp_approval/grp_approval_form";
	}
	
	@RequestMapping(value = "/grp_approval_sign", method = RequestMethod.GET)
	public String getApprovalSign() {
		return "grp_approval/grp_approval_sign";
	}
	
}