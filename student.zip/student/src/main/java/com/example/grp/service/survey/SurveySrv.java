package com.example.grp.service.survey;

import java.util.List;
import java.util.StringTokenizer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.grp.model.SurveyVO;
import com.example.grp.repository.survey.SurveyDao;

@Service
public class SurveySrv {

	@Autowired
	SurveyDao sDao;
	
	public void setSurvey(SurveyVO svo) {
		sDao.setSurvey(svo);
	}
	
	public List<SurveyVO> getSurveyOpen() {
		List<SurveyVO> list = sDao.getSurveyOpen(); //db 목록
		
		for(int i = 0; i < list.size(); i++) {
			String str = list.get(i).getSurvey_ex_cnt();
			
			//5|3|1|
			int sum = 0;
			StringTokenizer st = new StringTokenizer(str, "|");
			while( st.hasMoreTokens() ) {
				int cnt = Integer.parseInt(st.nextToken());
				sum += cnt;
			}
			
			list.get(i).setSurvey_total(sum); //더한 값을 다시 변수에 넣기
		}
		return list;
	}
	
	public List<SurveyVO> getSurveyClose() {
		return sDao.getSurveyClose();
	}
	
}





















