package com.example.grp.service.survey;

import java.util.List;
import java.util.StringTokenizer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.grp.model.SurveyVO;
import com.example.grp.repository.survey.SurveyDao;

@Service
public class SurveySrv {

	@Autowired
	SurveyDao sDao;
	
	public void setSurvey(SurveyVO svo) {
		sDao.setSurvey(svo);
	}
	
	public List<SurveyVO> getSurveyOpen() {
		List<SurveyVO> list = sDao.getSurveyOpen(); //db 목록
		
		for(int i = 0; i < list.size(); i++) {
			String str = list.get(i).getSurvey_ex_cnt();
			
			//5|3|1|
			int sum = 0;
			StringTokenizer st = new StringTokenizer(str, "|");
			while( st.hasMoreTokens() ) {
				int cnt = Integer.parseInt(st.nextToken());
				sum += cnt;
			}
			
			list.get(i).setSurvey_total(sum); //더한 값을 다시 변수에 넣기
		}
		return list;
	}
	
	public List<SurveyVO> getSurveyClose() {
		return sDao.getSurveyClose();
	}
	
	public SurveyVO getSurveyResult(int survey_id) {
		SurveyVO svo = sDao.getSurveyResult(survey_id);
		
		//5|3|1|
		int sum = 0;
		StringTokenizer st = new StringTokenizer(svo.getSurvey_ex_cnt(), "|");
		while( st.hasMoreTokens() ) {
			int cnt = Integer.parseInt(st.nextToken());//nextToken : 순서대로 하나씩 가져오기
			sum += cnt;
		}
		svo.setSurvey_total(sum);
		
		return svo;
	}
	
	public void setSurveyDo(SurveyVO svo) {
		
		SurveyVO vo = sDao.getSurveyResult(svo.getSurvey_id()); //디비에 저장된 기존 자료 가져오기
		
		StringTokenizer st = new StringTokenizer(vo.getSurvey_ex_cnt(), "|"); //2
		String[] arr = new String[st.countTokens()];
		
		int i = 0;
		String str = "";
		while(st.hasMoreTokens()) {
			arr[i] = st.nextToken();
			if( i == Integer.parseInt(svo.getRdo()) ) {
				int temp = Integer.parseInt(arr[i]);
				arr[i] = String.valueOf(++temp);
			}
			
			str += arr[i] + "|"; // 0|1|
			i++;
		}
		
		vo.setSurvey_ex_cnt(str);
		sDao.setSurveyDo(vo);
	}
	
	public void setSurveyStatusDo(SurveyVO svo) {
		sDao.setSurveyStatusDo(svo);
	}
	
}





















