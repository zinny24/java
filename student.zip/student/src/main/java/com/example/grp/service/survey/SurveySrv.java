package com.example.grp.service.survey;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.grp.model.SurveyVO;
import com.example.grp.repository.survey.SurveyDao;

@Service
public class SurveySrv {

	@Autowired
	SurveyDao sDao;
	
	public void setSurvey(SurveyVO svo) {
		sDao.setSurvey(svo);
	}
	
}





