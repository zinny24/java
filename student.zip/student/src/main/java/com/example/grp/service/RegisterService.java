package com.example.grp.service;

import java.util.List;

import com.example.grp.model.BuseoVO;
import com.example.grp.model.GradeVO;
import com.example.grp.model.RegisterVO;

public interface RegisterService {

	public List<BuseoVO> getBuseoList();
	
	public List<GradeVO> getGradeList();
	
	public int getEmpNumCheck(String empNum);
	
	public void setRegister(RegisterVO rvo);
	
	public void setRegisterOthersOne(RegisterVO rvo);
		
	public void setEmployeeAuthChange(String auth, String empNum);
	
	public void setEmployeeHeadChange(String headType, String empNum);
}
