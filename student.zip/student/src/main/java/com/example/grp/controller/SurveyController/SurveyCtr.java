package com.example.grp.controller.SurveyController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.grp.model.SurveyVO;
import com.example.grp.service.survey.SurveySrv;

@Controller
@RequestMapping("/survey")
public class SurveyCtr {
	
	@Autowired
	SurveySrv sSrv;
	
	@RequestMapping("/grp_survey")
	public String getSurvey() {
		return "grp_survey/grp_survey";
	}
	
	@RequestMapping("/grp_survey_add")
	@ResponseBody
	public void getSurveyAdd(@ModelAttribute SurveyVO svo) {
		
		String str = "";
		String num = "";
		for(int i = 0; i < svo.getSurvey_example().length; i++) { //보기 개수
			str += svo.getSurvey_example()[i]+"|";
			num += "0"+"|";
		}
		
		svo.setSurvey_ex(str); //한줄 변환한 값을 _ex 변수에 저장
		svo.setSurvey_ex_cnt(num); //보기의 초기값(0)을 변수에 저장
		
		sSrv.setSurvey(svo);
	}

	@RequestMapping("/grp_survey_open")
	public String getSurveyOpen() {
		return "grp_survey/grp_survey_open";
	}
	
	@RequestMapping("/grp_survey_close")
	public String getSurveyClose() {
		return "grp_survey/grp_survey_close";
	}
	
}











