package com.example.grp.controller.SurveyController;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.grp.model.SurveyVO;
import com.example.grp.service.survey.SurveySrv;

@Controller
@RequestMapping("/survey")
public class SurveyCtr {
	
	@Autowired
	SurveySrv sSrv;
	
	@RequestMapping("/grp_survey")
	public String getSurvey() {
		return "grp_survey/grp_survey";
	}
	
	@RequestMapping("/grp_survey_add")
	@ResponseBody
	public void getSurveyAdd(@ModelAttribute SurveyVO svo) throws ParseException {
		
		String str = "";
		String num = "";
		for(int i = 0; i < svo.getSurvey_example().length; i++) { //보기 개수
			str += svo.getSurvey_example()[i]+"|";
			num += "0"+"|";
		}
		
		svo.setSurvey_ex(str); //한줄 변환한 값을 _ex 변수에 저장
		svo.setSurvey_ex_cnt(num); //보기의 초기값(0)을 변수에 저장
		
		sSrv.setSurvey(svo);
		
		
	}

	@RequestMapping("/grp_survey_open")
	public ModelAndView getSurveyOpen() throws ParseException {
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("surveyOpen", sSrv.getSurveyOpen());
		mav.setViewName("grp_survey/grp_survey_open");
		
		//날짜 또는 시간이 경과될 때
		List<SurveyVO> list = sSrv.getSurveyOpen();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		for( int i = 0;  i < list.size(); i++ ) {
			Date s_date = sdf.parse(list.get(i).getSurvey_startDate());
			Date e_date = sdf.parse(list.get(i).getSurvey_endDate());
			
			Date today = new Date();
			long chkDate = today.getTime() - e_date.getTime() - (1000 * 60 * 60 *24);
			
			if( chkDate > 0 ) {
				list.get(i).setSurvey_status("설문대기중");
				sSrv.setSurveyStatusDo(list.get(i));
			}else {
				list.get(i).setSurvey_status("설문진행중");
				sSrv.setSurveyStatusDo(list.get(i));
			}	
		}
		return mav;
	}
	
	@RequestMapping("/grp_survey_close")
	public String getSurveyClose() {
		return "grp_survey/grp_survey_close";
	}
	
	@RequestMapping("/grp_survey_result")
	@ResponseBody
	public SurveyVO getSurveyResult(@RequestParam int survey_id) {
		return sSrv.getSurveyResult(survey_id);
	}
	
	@RequestMapping("/grp_survey_do")
	@ResponseBody
	public void setSurveyDo(@ModelAttribute SurveyVO svo) throws ParseException {
		sSrv.setSurveyDo(svo);
	}
}


















