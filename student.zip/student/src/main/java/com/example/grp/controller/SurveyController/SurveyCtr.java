package com.example.grp.controller.SurveyController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/survey")
public class SurveyCtr {
	
	@RequestMapping("/grp_survey")
	public String getSurvey() {
		return "grp_survey/grp_survey";
	}

	@RequestMapping("/grp_survey_open")
	public String getSurveyOpen() {
		return "grp_survey/grp_survey_open";
	}
	
	@RequestMapping("/grp_survey_close")
	public String getSurveyClose() {
		return "grp_survey/grp_survey_close";
	}
	
}