package com.example.grp.controller.AttendController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/attend")
public class AttendCtr {
	
	@RequestMapping("")
	public String getAttendHome() {
		return "grp_attend/grp_attend_main";
	}
	
}
