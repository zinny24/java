package com.example.grp.repository.survey;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.grp.model.SurveyVO;

@Repository
public class SurveyDao {

	@Autowired
	SqlSession sql;
	
	public void setSurvey(SurveyVO svo) {
		sql.insert("survey.setSurvey", svo);
	}
	
	public List<SurveyVO> getSurveyOpen() {
		return sql.selectList("survey.getSurveyOpen");
	}
	
	public List<SurveyVO> getSurveyClose() {
		return sql.selectList("survey.getSurveyClose");
	}
	
	public SurveyVO getSurveyResult(int survey_id) {
		return sql.selectOne("survey.getSurveyResult", survey_id);
	}
	
}








