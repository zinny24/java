package com.example.grp.repository.survey;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.grp.model.SurveyVO;

@Repository
public class SurveyDao {

	@Autowired
	SqlSession sql;
	
	public void setSurvey(SurveyVO svo) {
		sql.insert("survey.setSurvey", svo);
	}
	
}








